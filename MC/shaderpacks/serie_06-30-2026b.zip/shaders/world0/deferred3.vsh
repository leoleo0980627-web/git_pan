#version 430 compatibility
#define VERTEX
#include "/lib/uniforms.glsl"
#include "/program/deferred/d1_atrous_first.glsl"

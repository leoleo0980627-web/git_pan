#version 430 compatibility
#define VERTEX
#include "/lib/uniforms.glsl"
#include "/program/gbuffers/hand.glsl"
